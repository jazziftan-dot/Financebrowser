#Requires -Version 5.1
<#
.SYNOPSIS
    iCO - Cloud Defaults | Settings & Security  (Grundlagen 1-6 / Seiten 1-8)

.DESCRIPTION
    Automatisiert die "i-Community Grundlagen" aus dem Dokument
    "iCO - Cloud Defaults | Settings & Security" bis und mit Seite 8:

        Grundlage 1  - Emergency Admins (Break Glass)
        Grundlage 2  - RBAC Gruppen (role-assignable) + PIM-Voraussetzungsgruppen
        Grundlage 3  - Lizenz Gruppen
        Grundlage 4  - Shared Mailboxen (IT-Info / IT-Alerts) + Allow-Forwarding-Policy
        Grundlage 5  - iCO Admin (iCAdmin)
        Grundlage 6  - Teams Creation einschraenken (Sicherheitsgruppe + Tenant-Setting)

    Das Hardening Level 1 (ab Seite 9) ist NICHT Teil dieses Scripts.

.VORAUSSETZUNG
    Der Tenant MUSS eine "Microsoft Entra ID P2" Lizenz besitzen (Voraussetzung
    fuer PIM, siehe Grundlage 2). Ist keine P2-Lizenz vorhanden, bricht das
    Script ab und fuehrt keine Aenderungen durch.

.HINWEIS
    Das Script ist fuer ALLE Kunden ausfuehrbar. Zu Beginn oeffnet sich ein
    Eingabe-Fenster, in dem der Tenant-Name (onmicrosoft-Prefix) sowie die
    Domain fuer die Shared Mailboxen erfasst werden. Daraus wird z. B.
        EmergencyAdmin1@<Eingabe>.onmicrosoft.com

.BENOETIGTE MODULE
    Microsoft.Graph (Authentication, Users, Groups, Identity.DirectoryManagement,
                     Identity.Governance)
    ExchangeOnlineManagement

.AUTOR
    iCO - Cloud Defaults Automation
#>

[CmdletBinding()]
param(
    # Optional: Werte vorab uebergeben (ueberspringt das Popup-Fenster fuer diese Felder)
    [string]$TenantPrefix,
    [string]$SharedMailboxDomain,
    # Nur pruefen / anzeigen was passieren wuerde, ohne Aenderungen vorzunehmen
    [switch]$WhatIfMode
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

# ----------------------------------------------------------------------------
# Logging
# ----------------------------------------------------------------------------
$script:LogFile = Join-Path -Path $PSScriptRoot -ChildPath ("iCO-CloudDefaults_{0:yyyyMMdd_HHmmss}.log" -f (Get-Date))

function Write-Log {
    param(
        [Parameter(Mandatory)][string]$Message,
        [ValidateSet('INFO', 'OK', 'WARN', 'ERROR', 'STEP')][string]$Level = 'INFO'
    )
    $ts = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'
    $line = "[$ts] [$Level] $Message"
    switch ($Level) {
        'OK'    { Write-Host $line -ForegroundColor Green }
        'WARN'  { Write-Host $line -ForegroundColor Yellow }
        'ERROR' { Write-Host $line -ForegroundColor Red }
        'STEP'  { Write-Host ''; Write-Host $line -ForegroundColor Cyan }
        default { Write-Host $line -ForegroundColor Gray }
    }
    Add-Content -Path $script:LogFile -Value $line -ErrorAction SilentlyContinue
}

# ----------------------------------------------------------------------------
# Modul-Handling
# ----------------------------------------------------------------------------
function Confirm-Module {
    param([Parameter(Mandatory)][string]$Name)
    if (-not (Get-Module -ListAvailable -Name $Name)) {
        Write-Log "Modul '$Name' ist nicht installiert. Installiere (CurrentUser)..." 'WARN'
        try {
            Install-Module -Name $Name -Scope CurrentUser -Force -AllowClobber -ErrorAction Stop
            Write-Log "Modul '$Name' installiert." 'OK'
        } catch {
            throw "Modul '$Name' konnte nicht installiert werden: $($_.Exception.Message)"
        }
    }
}

# ----------------------------------------------------------------------------
# Eingabe-Fenster (Windows Forms)
# ----------------------------------------------------------------------------
function Show-InputForm {
    param(
        [string]$PrefilledTenant,
        [string]$PrefilledDomain
    )

    Add-Type -AssemblyName System.Windows.Forms
    Add-Type -AssemblyName System.Drawing

    $form = New-Object System.Windows.Forms.Form
    $form.Text          = 'iCO - Cloud Defaults | Tenant-Konfiguration'
    $form.Size          = New-Object System.Drawing.Size(560, 360)
    $form.StartPosition = 'CenterScreen'
    $form.FormBorderStyle = 'FixedDialog'
    $form.MaximizeBox   = $false
    $form.MinimizeBox   = $false
    $form.Topmost       = $true

    $lblIntro = New-Object System.Windows.Forms.Label
    $lblIntro.Text     = "Bitte den Tenant-Namen (onmicrosoft-Prefix) und die Domain fuer die`r`nShared Mailboxen erfassen. Beispiel-Ergebnis:`r`n   EmergencyAdmin1@<Tenant>.onmicrosoft.com"
    $lblIntro.Location = New-Object System.Drawing.Point(20, 15)
    $lblIntro.Size     = New-Object System.Drawing.Size(510, 60)
    $form.Controls.Add($lblIntro)

    # --- Tenant Prefix ---
    $lblTenant = New-Object System.Windows.Forms.Label
    $lblTenant.Text     = 'Tenant-Name (onmicrosoft-Prefix):'
    $lblTenant.Location = New-Object System.Drawing.Point(20, 90)
    $lblTenant.Size     = New-Object System.Drawing.Size(510, 20)
    $form.Controls.Add($lblTenant)

    $txtTenant = New-Object System.Windows.Forms.TextBox
    $txtTenant.Location = New-Object System.Drawing.Point(20, 112)
    $txtTenant.Size     = New-Object System.Drawing.Size(300, 24)
    $txtTenant.Text     = $PrefilledTenant
    $form.Controls.Add($txtTenant)

    $lblSuffix = New-Object System.Windows.Forms.Label
    $lblSuffix.Text     = '.onmicrosoft.com'
    $lblSuffix.Location = New-Object System.Drawing.Point(325, 115)
    $lblSuffix.Size     = New-Object System.Drawing.Size(150, 20)
    $form.Controls.Add($lblSuffix)

    # --- Shared Mailbox Domain ---
    $lblDomain = New-Object System.Windows.Forms.Label
    $lblDomain.Text     = 'Domain fuer Shared Mailboxen (z. B. kunde.ch - leer = onmicrosoft):'
    $lblDomain.Location = New-Object System.Drawing.Point(20, 150)
    $lblDomain.Size     = New-Object System.Drawing.Size(510, 20)
    $form.Controls.Add($lblDomain)

    $txtDomain = New-Object System.Windows.Forms.TextBox
    $txtDomain.Location = New-Object System.Drawing.Point(20, 172)
    $txtDomain.Size     = New-Object System.Drawing.Size(300, 24)
    $txtDomain.Text     = $PrefilledDomain
    $form.Controls.Add($txtDomain)

    # --- Vorschau ---
    $lblPreview = New-Object System.Windows.Forms.Label
    $lblPreview.Location  = New-Object System.Drawing.Point(20, 210)
    $lblPreview.Size      = New-Object System.Drawing.Size(510, 40)
    $lblPreview.ForeColor = [System.Drawing.Color]::DarkBlue
    $form.Controls.Add($lblPreview)

    $updatePreview = {
        $t = $txtTenant.Text.Trim()
        if ([string]::IsNullOrWhiteSpace($t)) {
            $lblPreview.Text = ''
        } else {
            $d = $txtDomain.Text.Trim()
            if ([string]::IsNullOrWhiteSpace($d)) { $d = "$t.onmicrosoft.com" }
            $lblPreview.Text = "Vorschau:`r`n  EmergencyAdmin1@$t.onmicrosoft.com`r`n  IT-Info@$d"
        }
    }
    $txtTenant.Add_TextChanged($updatePreview)
    $txtDomain.Add_TextChanged($updatePreview)

    # --- Buttons ---
    $btnOk = New-Object System.Windows.Forms.Button
    $btnOk.Text     = 'OK'
    $btnOk.Location = New-Object System.Drawing.Point(330, 275)
    $btnOk.Size     = New-Object System.Drawing.Size(90, 30)
    $btnOk.DialogResult = [System.Windows.Forms.DialogResult]::OK
    $form.Controls.Add($btnOk)
    $form.AcceptButton = $btnOk

    $btnCancel = New-Object System.Windows.Forms.Button
    $btnCancel.Text     = 'Abbrechen'
    $btnCancel.Location = New-Object System.Drawing.Point(430, 275)
    $btnCancel.Size     = New-Object System.Drawing.Size(90, 30)
    $btnCancel.DialogResult = [System.Windows.Forms.DialogResult]::Cancel
    $form.Controls.Add($btnCancel)
    $form.CancelButton = $btnCancel

    & $updatePreview

    $result = $form.ShowDialog()
    if ($result -ne [System.Windows.Forms.DialogResult]::OK) {
        return $null
    }

    $tenant = $txtTenant.Text.Trim().ToLower()
    # Falls jemand den vollen Suffix eingibt, kuerzen wir auf den Prefix
    $tenant = $tenant -replace '\.onmicrosoft\.com$', ''
    $domain = $txtDomain.Text.Trim().ToLower()
    if ([string]::IsNullOrWhiteSpace($domain)) { $domain = "$tenant.onmicrosoft.com" }

    if ([string]::IsNullOrWhiteSpace($tenant) -or $tenant -notmatch '^[a-z0-9][a-z0-9-]{0,61}[a-z0-9]$') {
        [System.Windows.Forms.MessageBox]::Show('Ungueltiger Tenant-Name. Bitte nur den onmicrosoft-Prefix angeben (z. B. "contoso").', 'Fehler', 'OK', 'Error') | Out-Null
        return (Show-InputForm -PrefilledTenant $txtTenant.Text -PrefilledDomain $txtDomain.Text)
    }

    return [pscustomobject]@{
        TenantPrefix        = $tenant
        OnMicrosoftDomain   = "$tenant.onmicrosoft.com"
        SharedMailboxDomain = $domain
    }
}

# ----------------------------------------------------------------------------
# Hilfsfunktionen
# ----------------------------------------------------------------------------
function New-ComplexPassword {
    # Komplexes Passwort mit min. 24 Zeichen (Grundlage 1)
    param([int]$Length = 28)
    $lower   = 'abcdefghijkmnopqrstuvwxyz'
    $upper   = 'ABCDEFGHJKLMNPQRSTUVWXYZ'
    $digits  = '23456789'
    $special = '!@#$%^&*()-_=+[]{}'
    $all     = $lower + $upper + $digits + $special

    $charArrL = $lower.ToCharArray();  $charArrU = $upper.ToCharArray()
    $charArrD = $digits.ToCharArray(); $charArrS = $special.ToCharArray()
    $charAll  = $all.ToCharArray()
    $pw = @(
        (Get-Random -InputObject $charArrL),
        (Get-Random -InputObject $charArrU),
        (Get-Random -InputObject $charArrD),
        (Get-Random -InputObject $charArrS)
    )
    for ($i = $pw.Count; $i -lt $Length; $i++) {
        $pw += (Get-Random -InputObject $charAll)
    }
    # mischen
    -join ($pw | Sort-Object { Get-Random })
}

function Get-OrCreateGroup {
    <#
        Erstellt eine (idempotente) Sicherheitsgruppe oder gibt die bestehende zurueck.
    #>
    param(
        [Parameter(Mandatory)][string]$DisplayName,
        [Parameter(Mandatory)][string]$Description,
        [switch]$RoleAssignable
    )
    $existing = Get-MgGroup -Filter "displayName eq '$DisplayName'" -ConsistencyLevel eventual -CountVariable c -ErrorAction SilentlyContinue
    if ($existing) {
        Write-Log "Gruppe '$DisplayName' existiert bereits (uebersprungen)." 'INFO'
        return ($existing | Select-Object -First 1)
    }
    if ($WhatIfMode) {
        Write-Log "[WhatIf] Wuerde Gruppe '$DisplayName' erstellen (RoleAssignable=$RoleAssignable)." 'WARN'
        return $null
    }
    $mailNick = ($DisplayName -replace '[^a-zA-Z0-9]', '')
    $params = @{
        DisplayName     = $DisplayName
        Description     = $Description
        MailEnabled     = $false
        MailNickname    = $mailNick
        SecurityEnabled = $true
    }
    if ($RoleAssignable) { $params['IsAssignableToRole'] = $true }
    $grp = New-MgGroup @params
    Write-Log "Gruppe '$DisplayName' erstellt." 'OK'
    return $grp
}

function Add-GroupMemberSafe {
    param(
        [Parameter(Mandatory)]$Group,
        [Parameter(Mandatory)][string]$UserId,
        [string]$UserUpn = ''
    )
    if (-not $Group) { return }
    if ($WhatIfMode) {
        Write-Log "[WhatIf] Wuerde '$UserUpn' zu Gruppe '$($Group.DisplayName)' hinzufuegen." 'WARN'
        return
    }
    $members = Get-MgGroupMember -GroupId $Group.Id -All -ErrorAction SilentlyContinue
    if ($members.Id -contains $UserId) {
        Write-Log "'$UserUpn' ist bereits Mitglied von '$($Group.DisplayName)'." 'INFO'
        return
    }
    New-MgGroupMember -GroupId $Group.Id -DirectoryObjectId $UserId
    Write-Log "'$UserUpn' zu '$($Group.DisplayName)' hinzugefuegt." 'OK'
}

function Get-OrCreateUser {
    param(
        [Parameter(Mandatory)][string]$Upn,
        [Parameter(Mandatory)][string]$DisplayName,
        [Parameter(Mandatory)][string]$MailNickname,
        [bool]$ForceChange = $false
    )
    $existing = Get-MgUser -Filter "userPrincipalName eq '$Upn'" -ErrorAction SilentlyContinue
    if ($existing) {
        Write-Log "Benutzer '$Upn' existiert bereits (uebersprungen)." 'INFO'
        return [pscustomobject]@{ User = ($existing | Select-Object -First 1); Password = $null; Created = $false }
    }
    if ($WhatIfMode) {
        Write-Log "[WhatIf] Wuerde Benutzer '$Upn' erstellen." 'WARN'
        return [pscustomobject]@{ User = $null; Password = $null; Created = $false }
    }
    $pw = New-ComplexPassword -Length 28
    $pwProfile = @{
        Password                      = $pw
        ForceChangePasswordNextSignIn = $ForceChange
    }
    $user = New-MgUser -AccountEnabled `
        -DisplayName $DisplayName `
        -UserPrincipalName $Upn `
        -MailNickname $MailNickname `
        -PasswordProfile $pwProfile `
        -UsageLocation 'CH'
    Write-Log "Benutzer '$Upn' erstellt." 'OK'
    return [pscustomobject]@{ User = $user; Password = $pw; Created = $true }
}

function Add-DirectoryRoleMember {
    <#
        Weist einem Principal eine eingebaute Verzeichnisrolle direkt zu
        (Grundlage 1: Global Admin wird direkt zugewiesen).
    #>
    param(
        [Parameter(Mandatory)][string]$PrincipalId,
        [Parameter(Mandatory)][string]$RoleDefinitionId,
        [string]$RoleName = ''
    )
    if ($WhatIfMode) {
        Write-Log "[WhatIf] Wuerde Rolle '$RoleName' zuweisen." 'WARN'
        return
    }
    $existing = Get-MgRoleManagementDirectoryRoleAssignment -Filter "principalId eq '$PrincipalId' and roleDefinitionId eq '$RoleDefinitionId'" -ErrorAction SilentlyContinue
    if ($existing) {
        Write-Log "Rolle '$RoleName' ist bereits zugewiesen." 'INFO'
        return
    }
    New-MgRoleManagementDirectoryRoleAssignment -PrincipalId $PrincipalId -RoleDefinitionId $RoleDefinitionId -DirectoryScopeId '/' | Out-Null
    Write-Log "Rolle '$RoleName' direkt zugewiesen." 'OK'
}

# ============================================================================
#  START
# ============================================================================
Write-Log "=== iCO - Cloud Defaults | Settings & Security (Grundlagen 1-6) ===" 'STEP'
Write-Log "Log-Datei: $script:LogFile"
if ($WhatIfMode) { Write-Log "WhatIf-Modus aktiv: es werden KEINE Aenderungen vorgenommen." 'WARN' }

# --- 0. Module sicherstellen ---------------------------------------------------
Write-Log "Pruefe benoetigte Module..." 'STEP'
$requiredGraph = @(
    'Microsoft.Graph.Authentication',
    'Microsoft.Graph.Users',
    'Microsoft.Graph.Groups',
    'Microsoft.Graph.Identity.DirectoryManagement',
    'Microsoft.Graph.Identity.Governance'
)
foreach ($m in $requiredGraph) { Confirm-Module -Name $m }
Confirm-Module -Name 'ExchangeOnlineManagement'

# --- 1. Eingabe-Fenster -------------------------------------------------------
Write-Log "Erfasse Tenant-Konfiguration..." 'STEP'
$config = $null
if ($TenantPrefix) {
    $prefix = ($TenantPrefix.Trim().ToLower() -replace '\.onmicrosoft\.com$', '')
    $dom = if ($SharedMailboxDomain) { $SharedMailboxDomain.Trim().ToLower() } else { "$prefix.onmicrosoft.com" }
    $config = [pscustomobject]@{
        TenantPrefix        = $prefix
        OnMicrosoftDomain   = "$prefix.onmicrosoft.com"
        SharedMailboxDomain = $dom
    }
    Write-Log "Parameter uebergeben - Eingabe-Fenster wird uebersprungen." 'INFO'
} else {
    $config = Show-InputForm -PrefilledTenant $TenantPrefix -PrefilledDomain $SharedMailboxDomain
}

if (-not $config) {
    Write-Log "Eingabe abgebrochen. Script wird beendet." 'ERROR'
    return
}
Write-Log "Tenant         : $($config.OnMicrosoftDomain)" 'OK'
Write-Log "Shared Mailbox : @$($config.SharedMailboxDomain)" 'OK'

# --- 2. Mit Microsoft Graph verbinden ----------------------------------------
Write-Log "Verbinde mit Microsoft Graph..." 'STEP'
$scopes = @(
    'User.ReadWrite.All',
    'Group.ReadWrite.All',
    'RoleManagement.ReadWrite.Directory',
    'Directory.ReadWrite.All',
    'Organization.Read.All'
)
Connect-MgGraph -Scopes $scopes -NoWelcome
$ctx = Get-MgContext
Write-Log "Verbunden als '$($ctx.Account)' (Tenant $($ctx.TenantId))." 'OK'

# --- 3. P2-Lizenz-Pruefung (Voraussetzung fuer PIM) ---------------------------
Write-Log "Pruefe Microsoft Entra ID P2 Lizenz (Voraussetzung)..." 'STEP'
$skus = Get-MgSubscribedSku -All
# AAD_PREMIUM_P2 ist der Service-Plan fuer Entra ID P2 (in EMSPREMIUM, AAD_PREMIUM_P2, M365 E5 usw.)
$p2Plans = $skus | Where-Object {
    $_.ServicePlans.ServicePlanName -contains 'AAD_PREMIUM_P2'
}

$hasP2 = $false
foreach ($sku in $p2Plans) {
    $plan = $sku.ServicePlans | Where-Object { $_.ServicePlanName -eq 'AAD_PREMIUM_P2' }
    $available = $sku.PrepaidUnits.Enabled - $sku.ConsumedUnits
    if (($plan.ProvisioningStatus -eq 'Success') -and ($sku.PrepaidUnits.Enabled -gt 0)) {
        $hasP2 = $true
        Write-Log "P2 gefunden in SKU '$($sku.SkuPartNumber)' (Enabled: $($sku.PrepaidUnits.Enabled), frei: $available)." 'OK'
    }
}

if (-not $hasP2) {
    Write-Log "ABBRUCH: Es wurde KEINE aktive 'Microsoft Entra ID P2' Lizenz gefunden." 'ERROR'
    Write-Log "PIM (Grundlage 2) setzt eine Entra ID P2 Lizenz voraus. Das Script fuehrt keine Aenderungen durch." 'ERROR'
    Disconnect-MgGraph | Out-Null
    return
}
Write-Log "Entra ID P2 vorhanden - Setup wird fortgesetzt." 'OK'

# Sammelobjekt fuer Zugangsdaten (Ausgabe am Ende)
$createdCredentials = New-Object System.Collections.Generic.List[object]

# ============================================================================
#  GRUNDLAGE 1 - Emergency Admins (Break Glass)
# ============================================================================
Write-Log "Grundlage 1 - Emergency Admins (Break Glass)" 'STEP'
$globalAdminRoleDefId = '62e90394-69f5-4237-9190-012177145e10'  # Global Administrator (fixe Template-ID)

$emergencyAdmins = @(
    @{ Upn = "EmergencyAdmin1@$($config.OnMicrosoftDomain)"; Display = 'Emergency Admin 1 (Break Glass)'; Nick = 'EmergencyAdmin1' },
    @{ Upn = "EmergencyAdmin2@$($config.OnMicrosoftDomain)"; Display = 'Emergency Admin 2 (Break Glass)'; Nick = 'EmergencyAdmin2' }
)

$emergencyAdminObjects = @()
foreach ($ea in $emergencyAdmins) {
    $res = Get-OrCreateUser -Upn $ea.Upn -DisplayName $ea.Display -MailNickname $ea.Nick -ForceChange:$false
    if ($res.User) {
        $emergencyAdminObjects += $res.User
        # Global Admin wird direkt zugewiesen (Doc: "Global Admin Rolle wird direkt zugewiesen")
        Add-DirectoryRoleMember -PrincipalId $res.User.Id -RoleDefinitionId $globalAdminRoleDefId -RoleName 'Global Administrator'
    }
    if ($res.Created -and $res.Password) {
        $createdCredentials.Add([pscustomobject]@{ Account = $ea.Upn; Password = $res.Password; Hinweis = 'Break Glass - OTP in Password Safe ablegen, MFA einrichten!' })
    }
}
Write-Log "WICHTIG: Break-Glass-Accounts gemaess Doc absichern: 24+ Zeichen PW, 2x MFA" 'WARN'
Write-Log "         (1x zentrale Telefonnummer +41 81 544 44 77, 1x OTP im Password Safe)." 'WARN'

# ============================================================================
#  GRUNDLAGE 2 - RBAC Gruppen (role-assignable) + PIM-Voraussetzungsgruppen
# ============================================================================
Write-Log "Grundlage 2 - RBAC Gruppen" 'STEP'
$rbacGroupsDef = @(
    @{ Name = 'G_AAD_RBAC_AdminRole-Level0'; Desc = 'Default Rolle, Basics Rights (Read Only)' },
    @{ Name = 'G_AAD_RBAC_AdminRole-Level1'; Desc = 'Default Rolle, Basics Rights (Helpdesk, Usermanagement)' },
    @{ Name = 'G_AAD_RBAC_AdminRole-Level2'; Desc = 'Extended Rolle, Collab Rights' },
    @{ Name = 'G_AAD_RBAC_AdminRole-Level3'; Desc = 'High Rolle, Highest Rights (Global Admin)' },
    @{ Name = 'G_AAD_RBAC_RoleAdmins';       Desc = 'RBAC - Role Admins (PIM Sicherheitsmechanismus)' },
    @{ Name = 'G_AAD_RBAC_EmergencyAdmins';  Desc = 'RBAC - Emergency Admins (Break Glass Gruppe)' }
)

$rbacGroups = @{}
foreach ($g in $rbacGroupsDef) {
    # Alle RBAC-Gruppen sind role-assignable (fuer PIM / Rollenzuweisung)
    $grp = Get-OrCreateGroup -DisplayName $g.Name -Description $g.Desc -RoleAssignable
    if ($grp) { $rbacGroups[$g.Name] = $grp }
}

# Emergency Admins der EmergencyAdmins-Gruppe hinzufuegen
if ($rbacGroups.ContainsKey('G_AAD_RBAC_EmergencyAdmins')) {
    foreach ($ea in $emergencyAdminObjects) {
        Add-GroupMemberSafe -Group $rbacGroups['G_AAD_RBAC_EmergencyAdmins'] -UserId $ea.Id -UserUpn $ea.UserPrincipalName
    }
}
Write-Log "Hinweis: PIM-Aktivierung & Rollen-Alarmierung (Global/Security/SharePoint Admin ->" 'WARN'
Write-Log "         IT-Info/IT-Alerts) sind im Entra Portal unter PIM zu konfigurieren." 'WARN'

# ============================================================================
#  GRUNDLAGE 3 - Lizenz Gruppen
# ============================================================================
Write-Log "Grundlage 3 - Lizenz Gruppen" 'STEP'
$licGroupsDef = @(
    @{ Name = 'G_AAD_LIC_M365BusinessStandard'; Desc = 'License | M365 Business Standard' },
    @{ Name = 'G_AAD_LIC_M365BusinessPremium';  Desc = 'License | M365 Business Premium' },
    @{ Name = 'G_AAD_LIC_ExchangeOnlinePlan1';  Desc = 'License | Exchange Online (Plan 1)' },
    @{ Name = 'G_AZ_LIC_MicrosofEntraIDP2';     Desc = 'License | Microsoft Entra ID P2' }
)
foreach ($g in $licGroupsDef) {
    Get-OrCreateGroup -DisplayName $g.Name -Description $g.Desc | Out-Null
}

# ============================================================================
#  GRUNDLAGE 4 - Shared Mailboxen (IT-Info / IT-Alerts) + Allow Forwarding
# ============================================================================
Write-Log "Grundlage 4 - Shared Mailboxen + Allow Forwarding" 'STEP'
try {
    Write-Log "Verbinde mit Exchange Online..." 'INFO'
    Connect-ExchangeOnline -ShowBanner:$false -ErrorAction Stop
    Write-Log "Mit Exchange Online verbunden." 'OK'

    $sharedMailboxes = @(
        @{ Name = 'IT-Info';   Display = 'IT Info';   Alias = 'IT-Info' },
        @{ Name = 'IT-Alerts'; Display = 'IT Alerts'; Alias = 'IT-Alerts' }
    )

    $smtpAddresses = @()
    foreach ($mb in $sharedMailboxes) {
        $smtp = "$($mb.Alias)@$($config.SharedMailboxDomain)"
        $smtpAddresses += $smtp
        $existingMb = Get-Mailbox -Identity $smtp -ErrorAction SilentlyContinue
        if ($existingMb) {
            Write-Log "Shared Mailbox '$smtp' existiert bereits (uebersprungen)." 'INFO'
        } elseif ($WhatIfMode) {
            Write-Log "[WhatIf] Wuerde Shared Mailbox '$smtp' erstellen." 'WARN'
        } else {
            New-Mailbox -Shared -Name $mb.Name -DisplayName $mb.Display -Alias $mb.Alias -PrimarySmtpAddress $smtp | Out-Null
            Write-Log "Shared Mailbox '$smtp' erstellt." 'OK'
        }
    }

    # Allow Forwarding (nur fuer diese 2 Mailboxen) via Outbound Spam Filter Policy + Rule
    $policyName = 'iCO-Allow-Forwarding'
    $existingPolicy = Get-HostedOutboundSpamFilterPolicy -Identity $policyName -ErrorAction SilentlyContinue
    if ($existingPolicy) {
        Write-Log "Outbound-Spam-Policy '$policyName' existiert bereits." 'INFO'
    } elseif ($WhatIfMode) {
        Write-Log "[WhatIf] Wuerde Outbound-Spam-Policy '$policyName' (AutoForwardingMode=On) erstellen." 'WARN'
    } else {
        New-HostedOutboundSpamFilterPolicy -Name $policyName -AutoForwardingMode On | Out-Null
        Write-Log "Outbound-Spam-Policy '$policyName' (AutoForwardingMode=On) erstellt." 'OK'
    }

    $ruleName = 'iCO-Allow-Forwarding'
    $existingRule = Get-HostedOutboundSpamFilterRule -Identity $ruleName -ErrorAction SilentlyContinue
    if ($existingRule) {
        Write-Log "Outbound-Spam-Rule '$ruleName' existiert bereits." 'INFO'
    } elseif ($WhatIfMode) {
        Write-Log "[WhatIf] Wuerde Outbound-Spam-Rule '$ruleName' fuer $($smtpAddresses -join ', ') erstellen." 'WARN'
    } else {
        New-HostedOutboundSpamFilterRule -Name $ruleName `
            -HostedOutboundSpamFilterPolicy $policyName `
            -From $smtpAddresses `
            -Priority 0 | Out-Null
        Write-Log "Outbound-Spam-Rule '$ruleName' erstellt (Forwarding erlaubt fuer: $($smtpAddresses -join ', '))." 'OK'
    }
} catch {
    Write-Log "Fehler bei Grundlage 4 (Exchange Online): $($_.Exception.Message)" 'ERROR'
    Write-Log "Grundlage 4 wurde uebersprungen - bitte manuell pruefen." 'WARN'
} finally {
    try { Disconnect-ExchangeOnline -Confirm:$false -ErrorAction SilentlyContinue } catch {}
}

# ============================================================================
#  GRUNDLAGE 5 - iCO Admin (iCAdmin)
# ============================================================================
Write-Log "Grundlage 5 - iCO Admin (iCAdmin)" 'STEP'
$icAdminUpn = "iCAdmin@$($config.OnMicrosoftDomain)"
$icRes = Get-OrCreateUser -Upn $icAdminUpn -DisplayName 'iCO Admin (iCAdmin)' -MailNickname 'iCAdmin' -ForceChange:$true
if ($icRes.Created -and $icRes.Password) {
    $createdCredentials.Add([pscustomobject]@{ Account = $icAdminUpn; Password = $icRes.Password; Hinweis = 'iCO Admin - unter PIM stellen, in alle RBAC-Rollen integriert.' })
}
if ($icRes.User) {
    # In alle RBAC-Rollen-Gruppen integrieren (Doc: "in alle RBAC Rollen integriert")
    foreach ($lvl in 'G_AAD_RBAC_AdminRole-Level0', 'G_AAD_RBAC_AdminRole-Level1', 'G_AAD_RBAC_AdminRole-Level2', 'G_AAD_RBAC_AdminRole-Level3', 'G_AAD_RBAC_RoleAdmins') {
        if ($rbacGroups.ContainsKey($lvl)) {
            Add-GroupMemberSafe -Group $rbacGroups[$lvl] -UserId $icRes.User.Id -UserUpn $icAdminUpn
        }
    }
}
Write-Log "Hinweis: iCAdmin gemaess Doc unter PIM stellen (Absicherung der Admin-Rollen)." 'WARN'

# ============================================================================
#  GRUNDLAGE 6 - Teams Creation einschraenken
# ============================================================================
Write-Log "Grundlage 6 - Teams Creation einschraenken" 'STEP'
$teamsGroup = Get-OrCreateGroup -DisplayName 'G_AAD_SEC_TEAMS_CreateTeams_Allow' -Description 'Security | Allow Users to Create Teams'

if ($teamsGroup) {
    if ($WhatIfMode) {
        Write-Log "[WhatIf] Wuerde Group.Unified Setting setzen: EnableGroupCreation=false, GroupCreationAllowedGroupId=$($teamsGroup.Id)." 'WARN'
    } else {
        try {
            # Directory Setting 'Group.Unified' via Graph REST setzen/aktualisieren
            $settings = Invoke-MgGraphRequest -Method GET -Uri 'https://graph.microsoft.com/v1.0/groupSettings'
            $unified = $settings.value | Where-Object { $_.templateId -eq '62375ab9-6b52-47ed-826b-58e47e0e304b' } | Select-Object -First 1

            if (-not $unified) {
                # Template laden und neues Setting anlegen
                $template = Invoke-MgGraphRequest -Method GET -Uri "https://graph.microsoft.com/v1.0/groupSettingTemplates/62375ab9-6b52-47ed-826b-58e47e0e304b"
                $values = @()
                foreach ($v in $template.values) {
                    $val = $v.defaultValue
                    if ($v.name -eq 'EnableGroupCreation')         { $val = 'false' }
                    if ($v.name -eq 'GroupCreationAllowedGroupId')  { $val = $teamsGroup.Id }
                    $values += @{ name = $v.name; value = "$val" }
                }
                $body = @{ templateId = '62375ab9-6b52-47ed-826b-58e47e0e304b'; values = $values } | ConvertTo-Json -Depth 5
                Invoke-MgGraphRequest -Method POST -Uri 'https://graph.microsoft.com/v1.0/groupSettings' -Body $body -ContentType 'application/json' | Out-Null
                Write-Log "Group.Unified Setting erstellt: Teams-Erstellung auf 'G_AAD_SEC_TEAMS_CreateTeams_Allow' beschraenkt." 'OK'
            } else {
                $values = @()
                foreach ($v in $unified.values) {
                    $val = $v.value
                    if ($v.name -eq 'EnableGroupCreation')         { $val = 'false' }
                    if ($v.name -eq 'GroupCreationAllowedGroupId')  { $val = $teamsGroup.Id }
                    $values += @{ name = $v.name; value = "$val" }
                }
                $body = @{ values = $values } | ConvertTo-Json -Depth 5
                Invoke-MgGraphRequest -Method PATCH -Uri "https://graph.microsoft.com/v1.0/groupSettings/$($unified.id)" -Body $body -ContentType 'application/json' | Out-Null
                Write-Log "Group.Unified Setting aktualisiert: Teams-Erstellung auf 'G_AAD_SEC_TEAMS_CreateTeams_Allow' beschraenkt." 'OK'
            }
        } catch {
            Write-Log "Fehler beim Setzen des Group.Unified Settings: $($_.Exception.Message)" 'ERROR'
            Write-Log "Bitte EnableGroupCreation=false und GroupCreationAllowedGroupId manuell setzen." 'WARN'
        }
    }
}

# ============================================================================
#  ABSCHLUSS - Zusammenfassung & Zugangsdaten
# ============================================================================
Write-Log "=== Setup abgeschlossen (Grundlagen 1-6 / Seiten 1-8) ===" 'STEP'

if ($createdCredentials.Count -gt 0) {
    Write-Host ''
    Write-Host '====================================================================' -ForegroundColor Yellow
    Write-Host ' NEU ERSTELLTE ZUGANGSDATEN - sicher im Password Safe ablegen!' -ForegroundColor Yellow
    Write-Host '====================================================================' -ForegroundColor Yellow
    $createdCredentials | Format-Table -AutoSize -Wrap | Out-String | Write-Host

    # Zusaetzlich verschluesselt/separat als Datei (nur lokal, Klartext - bewusst nur fuer Uebergabe)
    $credFile = Join-Path -Path $PSScriptRoot -ChildPath ("iCO-Credentials_{0:yyyyMMdd_HHmmss}.txt" -f (Get-Date))
    $createdCredentials | Format-Table -AutoSize -Wrap | Out-String | Set-Content -Path $credFile
    Write-Log "Zugangsdaten zusaetzlich gespeichert unter: $credFile" 'WARN'
    Write-Log "WICHTIG: Diese Datei nach der Uebergabe / Ablage im Password Safe loeschen!" 'WARN'
} else {
    Write-Log "Keine neuen Accounts erstellt (alles bereits vorhanden oder WhatIf-Modus)." 'INFO'
}

Write-Log "Vollstaendiges Log: $script:LogFile" 'OK'

try { Disconnect-MgGraph | Out-Null } catch {}
Write-Log "Verbindung getrennt. Fertig." 'OK'
